# Back end take home
## Overview
This is a fictional Stock Trading API project.  
The project currently supports creating an account (with some less than perfect code).
You'll be adding support for _making trades_ (Does it mean that this api has to support to submit a order, match, 
execute, orderbook update, broadcast orderbook, and alert client the whole life cycle trading or submit a order and 
return the received order info back to the client?), and doing some light refactoring work on the existing code.

### What's ~~a trade~~ an order?
For the purposes of this exercise, ~~a trade~~ An order represents the Buying or Selling of a Stock.
~~A trade~~ An order includes the following properties:

- symbol (e.g. 'AAPL' for Apple)
- quantity
- side (buy or sell)
- price
- status (SUBMITTED, CANCELLED, COMPLETED, or FAILED)

## Tasks
Make sure to write tests (JUnit 5 or Spock).  Create a branch for the following:

1.  Design the table(s) to store trades made for an account
1.  Create the associated flyway migrations. 
1.  Create a ReSTful API that 
    1. Submits a new trade.
        - Quantity & price must be > 0
    1. Reads existing trades.
    1. Cancels a trade that's still in a SUBMITTED status.
1.  Refactor any poorly structured code you find in the Account related code. 
1.  Fix the error handling so that the API doesn't return any 5xx responses.

## Building the project
    ./gradlew clean build

## Running the project
    ./gradlew bootRun
    
## System Requirement Analysis and Design
    It is very easy to be confused with order and trade. An order (or order entry) is a trade request without any 
    counterparty info. A trade usually means matched orders with counterparty. It co-exists as a pair. I understand that
    this tiny project is required to implement an order api. 
## 1, This stock trading API will only implement the following features:
##    1.1 Receive a new order
##        1.1.1 new order request
            def new order {:symbol,:account, :quantity, :side, :price}
##        1.1.2 new order response 
            def return order {:orderId, :serverId, :machineId, :eventId, :symbol, :account, :quantity, :side, :price, 
            :sessionDate, :msg_seq}
##        1.1.3 api call: post
##        1.1.4 new order processing
            a. api receives a new order request, populate [sessionDate] etc and send it to gateway.
            b. gateway will populate [serverId, machineId] and route the order to right engine server instance  
                based on stock symbol
            c. engine server instance will populate [eventId, msg_seq], persist it in database both Orders and 
                Order_History tables, ack gateway with eventId and msg_seq at the same time (update orderbook, and 
                orderbook will broadcast the change, if a match happens, order book will generate a match event and 
                broadcast all registered parties, the corresponding matched parties will receive alert notifications. 
                these features will be future state of the project, not in this impl.)
            d. gateway assembly the right info and send ack to api.
            e. api assembly the right info and send response back to client.
##    1.2 Cancel an existing order
##        1.2.1 cancel order request
            def cancel order {:orderId, :eventId, :machinedId, :serverId}
##        1.2.2 cancel order response OK or REJECT (future state - alert notification)
##        1.2.3 api call post
##        1.2.4 cancel order processing
            a. api receives a cancel order request and send it to gateway.
            b. gateway route the order to right engine server instance based on cancel request
            c. engine server will populate a new row in database Orders tables, arc gateway ok or reject based on status
                and (update orderbook, and orderbook will broadcast the change, the client will be alerted)
            d. gateway ack ok to api.
            e. api will send response ok back to client.
##      1.3 Order Retrieve
##          1.3.1 The order retrieve api will support retrieve all orders by account_id.
##      1.4 For quick prototype, we put engine, gateway and messaging altogether. In prod env, they should deploy independently.
