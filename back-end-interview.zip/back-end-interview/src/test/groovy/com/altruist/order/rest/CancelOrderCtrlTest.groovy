package com.altruist.order.rest

import com.altruist.order.dto.CancelOrderDto
import com.altruist.order.dto.CancelOrderResponse
import com.altruist.order.dto.ValidateAndConvertCancelOrder
import com.altruist.order.services.CancelOrderSrv
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.ResultActions
import spock.lang.Specification
import spock.mock.DetachedMockFactory


import static org.springframework.http.MediaType.APPLICATION_JSON
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status

@WebMvcTest(controllers = [CancelOrderCtrl])
class CancelOrderCtrlTest extends Specification {
    @Autowired
    MockMvc mvc

    @Autowired
    ObjectMapper objectMapper

    @Autowired
    CancelOrderSrv mockCancelOrderSrv

    def "Should accept cancel order request"() {
        given: "an new order request"
        CancelOrderDto req = new CancelOrderDto(
                orderId: UUID.randomUUID().toString(),
                serverId: "localhost",
                machineId: "127.0.0.1",
                eventId: 1)
        CancelOrderResponse expected = new CancelOrderResponse()
        expected.orderId = UUID.fromString(req.orderId)
        expected.successful = true
        expected.reason = "Canceled by Client"

        when: "the request is submitted"
        ResultActions results = mvc.perform(post("/cancel")
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req))
        )

        then: "the request is processed"
        1 * mockCancelOrderSrv.sendCancelOrder(ValidateAndConvertCancelOrder.convertDtoToModel(req)) >> expected

        and: "a OK response is returned"
        results.andExpect(status().isOk())
    }

    @TestConfiguration
    static class TestConfig {
        DetachedMockFactory factory = new DetachedMockFactory()

        @Bean
        CancelOrderSrv cancelOrderSrv() {
            factory.Mock(CancelOrderSrv)
        }
    }
}
