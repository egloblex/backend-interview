package com.altruist.order.services

import com.altruist.order.dto.CancelOrderDto
import com.altruist.order.dto.ValidateAndConvertCancelOrder
import com.altruist.order.messaging.OrderBus
import spock.lang.Specification
import spock.lang.Unroll

class CancelOrderSrvTest extends Specification {
    OrderBus mockOrdersBus = Mock()
    CancelOrderSrv srv = new CancelOrderSrv(mockOrdersBus)

    @Unroll
    def "Should validate for missing order field #field"() {
        given: "an new order missing fields"
        CancelOrderDto order = new CancelOrderDto(
                orderId: UUID.randomUUID(),
                serverId: "localhost",
                machineId: "127.0.0.1",
                eventId: 1,
        )
        order[field] = null

        when:
        srv.sendCancelOrder(ValidateAndConvertCancelOrder.convertDtoToModel(order))

        then:
        thrown(NullPointerException)

        where:
        field << ["orderId", "serverId", "machineId","eventId"]
    }
}
