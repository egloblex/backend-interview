package com.altruist.order.rest


import com.altruist.order.dto.NewOrderDto
import com.altruist.order.dto.OrderEntry
import com.altruist.order.dto.ValidateAndConvertNewOrder
import com.altruist.order.services.NewOrderSrv
import com.altruist.order.services.OrderRetrieveSrv
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.ResultActions
import spock.lang.Specification
import spock.mock.DetachedMockFactory

import java.time.LocalDate
import java.time.LocalDateTime

import static org.springframework.http.MediaType.APPLICATION_JSON
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status

@WebMvcTest(controllers = [OrderRetrieveCtrl])
class OrderRetrieveCtrlTest extends Specification {
    @Autowired
    MockMvc mvc

    @Autowired
    ObjectMapper objectMapper

    @Autowired
    OrderRetrieveSrv mockOrderRetrieveSrv

    def "Should accept new order requests"() {
        given: "an new order request"

        List<OrderEntry> expList = new ArrayList<>();
        OrderEntry expected = new OrderEntry()
        expected.account = UUID.randomUUID()
        expected.engRecTime = LocalDateTime.now()
        expected.symbol = "aapl"
        expected.eventId = 1
        expected.msgSeq =1
        expected.orderId = UUID.randomUUID()
        expected.price = 430.30
        expected.quantity = 100
        expected.serverId = "localhost"
        expected.machineId = "127.0.0.1"
        expected.sessionDate = LocalDate.now()
        expected.side = 1
        expList.add(expected)


        when: "the request is submitted"
        ResultActions results = mvc.perform(post("/orders/" + expected.account.toString())
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(expList))
        )

        then: "the request is processed"
        1 * mockOrderRetrieveSrv.retrieveOrderEntries(expected.account.toString()) >> expList

        and: "a retrieve response is returned"
        results.andExpect(status().isOk())
    }

    @TestConfiguration
    static class TestConfig {
        DetachedMockFactory factory = new DetachedMockFactory()

        @Bean
        OrderRetrieveSrv orderRetrieveSrv() {
            factory.Mock(OrderRetrieveSrv)
        }
    }
}
