package com.altruist.order.services

import com.altruist.order.dto.NewOrderDto
import com.altruist.order.dto.ValidateAndConvertNewOrder
import com.altruist.order.messaging.OrderBus
import spock.lang.Specification
import spock.lang.Unroll

class NewOrderSrvTest extends Specification {
    OrderBus mockOrdersBus = Mock()
    NewOrderSrv srv = new NewOrderSrv(mockOrdersBus)

    @Unroll
    def "Should validate for missing symbol field #field"() {
        given: "an new order missing fields"
        NewOrderDto order = new NewOrderDto(
                symbol: "aapl",
                account: UUID.randomUUID(),
                quantity: 100,
                side: 1,
                price: 430.30
        )
        order[field] = null

        when:
        srv.sendNewOrder(ValidateAndConvertNewOrder.convertDtoToModel(order))

        then:
        thrown(NullPointerException)

        where:
        field << ["symbol", "account", "quantity","side","price"]
    }
}
