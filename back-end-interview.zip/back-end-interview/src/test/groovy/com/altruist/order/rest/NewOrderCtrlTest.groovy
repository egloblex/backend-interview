package com.altruist.order.rest

import com.altruist.account.AccountCtrl
import com.altruist.account.AccountSrv
import com.altruist.order.dto.NewOrderDto
import com.altruist.order.dto.OrderEntry
import com.altruist.order.dto.ValidateAndConvertNewOrder
import com.altruist.order.services.NewOrderSrv
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.ResultActions
import spock.lang.Specification
import spock.mock.DetachedMockFactory

import java.time.LocalDate
import java.time.LocalDateTime

import static org.hamcrest.Matchers.containsString
import static org.springframework.http.MediaType.APPLICATION_JSON
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*

@WebMvcTest(controllers = [NewOrderCtrl])
class NewOrderCtrlTest extends Specification {
    @Autowired
    MockMvc mvc

    @Autowired
    ObjectMapper objectMapper

    @Autowired
    NewOrderSrv mockNewOrderSrv

    def "Should accept new order requests"() {
        given: "an new order request"
        NewOrderDto req = new NewOrderDto(
                symbol: "aapl",
                account: UUID.randomUUID(),
                quantity: 100,
                side: 1,
                price: 430.30
        )
        OrderEntry expected = new OrderEntry()
        expected.account = UUID.fromString(req.account)
        expected.engRecTime = LocalDateTime.now()
        expected.symbol = "aapl"
        expected.eventId = 1
        expected.msgSeq =1
        expected.orderId = UUID.randomUUID()
        expected.price = 430.30
        expected.quantity = 100
        expected.serverId = "localhost"
        expected.machineId = "127.0.0.1"
        expected.sessionDate = LocalDate.now()
        expected.side = 1

        when: "the request is submitted"
        ResultActions results = mvc.perform(post("/orders")
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req))
        )

        then: "the request is processed"
        1 * mockNewOrderSrv.sendNewOrder(ValidateAndConvertNewOrder.convertDtoToModel(req)) >> expected

        and: "a Created response is returned"
        results.andExpect(status().isCreated())
    }

    @TestConfiguration
    static class TestConfig {
        DetachedMockFactory factory = new DetachedMockFactory()

        @Bean
        NewOrderSrv newOrderSrv() {
            factory.Mock(NewOrderSrv)
        }
    }
}
