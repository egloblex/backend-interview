package com.altruist.order.repo

import com.altruist.account.Account
import com.altruist.account.AccountRepo
import com.altruist.config.DbConfig
import com.altruist.config.RepoConfig
import com.altruist.order.dto.OrderEntry
import groovy.sql.Sql
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.data.jdbc.DataJdbcTest
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.FilterType
import org.springframework.context.annotation.Import
import org.springframework.stereotype.Repository
import org.springframework.test.annotation.Rollback
import org.springframework.test.context.ActiveProfiles
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Stepwise

import java.time.LocalDate
import java.time.LocalDateTime

@ActiveProfiles("test")
@DataJdbcTest(includeFilters = [@ComponentScan.Filter(type = FilterType.ANNOTATION, value = [Repository])])
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(value = [DbConfig, RepoConfig])
@Stepwise
@Rollback(false)
class OrdersRepoTest extends Specification {
    @Autowired
    OrdersRepo repo
    @Shared
    OrderEntry orderEntry

    def "Inserts a new order"() {
        given: "an order"
        OrderEntry orderEntry = new OrderEntry()
        orderEntry.account = UUID.randomUUID()
        orderEntry.engRecTime = LocalDateTime.now()
        orderEntry.symbol = "aapl"
        orderEntry.eventId = 1
        orderEntry.msgSeq =1
        orderEntry.price = 430.30
        orderEntry.quantity = 100
        orderEntry.serverId = "localhost"
        orderEntry.machineId = "127.0.0.1"
        orderEntry.sessionDate = LocalDate.now()
        orderEntry.side = 1
        orderEntry.status = 1

        when:
        repo.saveOrders(orderEntry)

        then: "the order id is returned"
        orderEntry.orderId
    }
}
