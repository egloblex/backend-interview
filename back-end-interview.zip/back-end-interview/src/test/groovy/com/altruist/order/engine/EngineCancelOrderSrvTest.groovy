package com.altruist.order.engine

import com.altruist.config.DbConfig
import com.altruist.config.RepoConfig
import com.altruist.order.dto.CancelOrderResponse
import com.altruist.order.dto.OrderEntry
import com.altruist.order.dto.OrderEntryToCancelOrderRequest
import com.altruist.order.repo.OrdersRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.data.jdbc.DataJdbcTest
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.FilterType
import org.springframework.context.annotation.Import
import org.springframework.stereotype.Repository
import org.springframework.test.annotation.Rollback
import org.springframework.test.context.ActiveProfiles
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Stepwise

import java.time.LocalDate
import java.time.LocalDateTime

@ActiveProfiles("test")
@DataJdbcTest(includeFilters = [@ComponentScan.Filter(type = FilterType.ANNOTATION, value = [Repository])])
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(value = [DbConfig, RepoConfig])
@Stepwise
@Rollback(false)
class EngineCancelOrderSrvTest extends Specification {
    @Autowired
    OrdersRepo repo
    @Shared
    OrderEntry orderEntry

    def "Inserts a new order"() {
        given: "an order"
        orderEntry = new OrderEntry()
        orderEntry.account = UUID.randomUUID()
        orderEntry.engRecTime = LocalDateTime.now()
        orderEntry.symbol = "aapl"
        orderEntry.eventId = 1
        orderEntry.msgSeq =1
        orderEntry.price = 430.30
        orderEntry.quantity = 100
        orderEntry.serverId = "localhost"
        orderEntry.machineId = "127.0.0.1"
        orderEntry.sessionDate = LocalDate.now()
        orderEntry.side = 1
        orderEntry.status = 1

        and: "engine order service is under testing"
        EngineOrdersSrv srv = new EngineOrdersSrv(repo)
        EngineCancelOrderSrv cancelSrc = new EngineCancelOrderSrv(repo)

        when: "save a new order and cancel it"
        CancelOrderResponse ret = cancelSrc.cancelOrder(OrderEntryToCancelOrderRequest.convertOEToCOR(srv.saveNewOrder(orderEntry)))

        then: "thie order status is canceled"
        ret.successful
    }
}
