package com.altruist.order.services

import com.altruist.order.dto.CancelOrderDto
import com.altruist.order.dto.ValidateAndConvertCancelOrder
import com.altruist.order.messaging.OrderBus
import com.altruist.order.repo.OrdersRepo
import spock.lang.Specification
import spock.lang.Unroll

class OrderRetrieveSrvTest extends Specification {
    OrdersRepo mockOrdersRepo = Mock()
    OrderRetrieveSrv srv = new OrderRetrieveSrv(mockOrdersRepo)

    @Unroll
    def "Should validate for missing symbol field #field"() {
        given: "an new order missing fields"

        field = "_"

        when:
        srv.retrieveOrderEntries(field)

        then:
        thrown(IllegalArgumentException)

        where:
        field << ["","_","*","@","123","1-2-3"]
    }
}
