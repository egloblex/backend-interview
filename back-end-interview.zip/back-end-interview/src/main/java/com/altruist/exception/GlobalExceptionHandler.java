package com.altruist.exception;

import com.altruist.common.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.TypeMismatchException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({InvalidRequestException.class})
    protected ResponseEntity<Object> handleInvalidRequest(RuntimeException ex, WebRequest request) {
        InvalidRequestException ire = (InvalidRequestException) ex;
        List<ErrorResource> errorResources = new ArrayList<>();
        List<FieldError> fieldErrors = null;
        ErrorResource lvErrorResource;

        if (ire.getErrors() != null) {
            fieldErrors = ire.getErrors().getFieldErrors();
            for (ObjectError fieldError : ire.getErrors().getGlobalErrors()) {
                lvErrorResource = new ErrorResource();
                lvErrorResource.setResource(fieldError.getObjectName());
                lvErrorResource.setCode(fieldError.getClass().getCanonicalName());
                lvErrorResource.setField(fieldError.getCode());
                lvErrorResource.setMessage(fieldError.getDefaultMessage());
                errorResources.add(lvErrorResource);
            }

            Collections.reverse(Arrays.asList(fieldErrors));

            for (FieldError fieldError : fieldErrors) {
                lvErrorResource = new ErrorResource();
                lvErrorResource.setResource(fieldError.getObjectName());
                lvErrorResource.setField(fieldError.getField());
                lvErrorResource.setCode(fieldError.getCode());
                lvErrorResource.setMessage(fieldError.getDefaultMessage());
                errorResources.add(lvErrorResource);
            }
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return handleExceptionInternal(ex, processError(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), errorResources),
                headers, HttpStatus.OK, request);
    }

    @ExceptionHandler(NullPointerException.class)
    protected ResponseEntity<Object> handleNullPointer(RuntimeException ex, WebRequest request) {
        return handleInvalidData(ex, request);
    }

    @ExceptionHandler(URISyntaxException.class)
    protected ResponseEntity<Object> handleURISyntax(RuntimeException ex, WebRequest request) {
        return handleInvalidData(ex, request);
    }

    @ExceptionHandler({InvalidDataException.class})
    protected ResponseEntity<Object> handleInvalidData(RuntimeException ex, WebRequest request) {
        InvalidDataException ide = (InvalidDataException) ex;
        List<ErrorResource> errorResources = new ArrayList<>();
        List<FieldError> fieldErrors = null;
        ErrorResource lvErrorResource;

        if (ide.getErrors() != null) {
            fieldErrors = ide.getErrors().getFieldErrors();
            for (ObjectError fieldError : ide.getErrors().getGlobalErrors()) {
                lvErrorResource = new ErrorResource();
                lvErrorResource.setResource(fieldError.getObjectName());
                lvErrorResource.setCode(fieldError.getClass().getCanonicalName());
                lvErrorResource.setField(mapFieldToErrMessage(ide.getEnumClass(), fieldError.getCode(), fieldError.getDefaultMessage()));
                lvErrorResource.setMessage(mapMessageToErrMessage(ide.getEnumClass(), fieldError.getDefaultMessage()));
                errorResources.add(lvErrorResource);
            }

            Collections.reverse(Arrays.asList(fieldErrors));

            for (FieldError fieldError : fieldErrors) {
                lvErrorResource = new ErrorResource();
                lvErrorResource.setResource(fieldError.getObjectName());
                lvErrorResource.setField(mapFieldToErrMessage(ide.getEnumClass(), fieldError.getField(), fieldError.getDefaultMessage()));
                lvErrorResource.setCode(fieldError.getCode());
                lvErrorResource.setMessage(mapMessageToErrMessage(ide.getEnumClass(), fieldError.getDefaultMessage()));
                errorResources.add(lvErrorResource);
            }
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return handleExceptionInternal(ex, processError(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), errorResources),
                headers, HttpStatus.OK, request);
    }

    // 401
    @ExceptionHandler({UnAuthorizedException.class})
    protected ResponseEntity<Object> handleMethodUnAuthorizedException(RuntimeException ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        final APIResponseData apiError = new APIResponseData(HttpStatus.UNAUTHORIZED.value(), HttpStatus.UNAUTHORIZED.getReasonPhrase());
        return handleExceptionInternal(ex, apiError, headers, HttpStatus.OK, request);
    }

    // 404
    @ExceptionHandler({DataNotFoundException.class})
    protected ResponseEntity<Object> handleMethodDataNotFoundException(RuntimeException ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        final APIResponseData apiError = new APIResponseData(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
        return handleExceptionInternal(ex, apiError, headers, HttpStatus.OK, request);
    }

    // 400
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            final MethodArgumentNotValidException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final APIResponseData apiError = new APIResponseData(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase());
        return handleExceptionInternal(ex, apiError, headers, HttpStatus.OK, request);
    }

    @Override
    protected ResponseEntity<Object> handleBindException(
            final BindException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final APIResponseData apiError = new APIResponseData(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase());
        if (ex.hasErrors()) {
            apiError.getStatus().setErrors(setBindErrorMessage(ex));
        }
        return handleExceptionInternal(ex, apiError, headers, HttpStatus.OK, request);
    }

    private List<ErrorResource> setBindErrorMessage(BindException ex) {
        List<ErrorResource> errors = new ArrayList<>();
        ErrorResource error = new ErrorResource();
        error.setField(ex.getFieldError().getField());
        error.setMessage(ex.getFieldError().getDefaultMessage());

        errors.add(error);
        return errors;
    }

    @Override
    protected ResponseEntity<Object> handleTypeMismatch(
            final TypeMismatchException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final String error = ex.getValue() + " value for " + ex.getPropertyName() + " should be of type " + ex.getRequiredType();
        final APIResponseData apiError = new APIResponseData(HttpStatus.BAD_REQUEST.value(), error);
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestPart(
            final MissingServletRequestPartException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final String error = ex.getRequestPartName() + " part is missing";
        final APIResponseData apiError = new APIResponseData(HttpStatus.BAD_REQUEST.value(), error);
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            final MissingServletRequestParameterException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final String error = ex.getParameterName() + " parameter is missing";
        final APIResponseData apiError = new APIResponseData(HttpStatus.BAD_REQUEST.value(), error);
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    // 404
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(
            final NoHandlerFoundException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final String error = "No handler found for " + ex.getHttpMethod() + " " + ex.getRequestURL();
        final APIResponseData apiError = new APIResponseData(HttpStatus.NOT_FOUND.value(), error);
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    // 405
    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            final HttpRequestMethodNotSupportedException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final StringBuilder builder = new StringBuilder();
        builder.append(ex.getMethod());
        builder.append(" method is not supported for this request. Supported methods are ");
        ex.getSupportedHttpMethods().forEach(t -> builder.append(t + " "));

        final APIResponseData apiError = new APIResponseData(HttpStatus.METHOD_NOT_ALLOWED.value(), builder.toString());
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    // 415
    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
            final HttpMediaTypeNotSupportedException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        logger.info(ex.getClass().getName());
        final StringBuilder builder = new StringBuilder();
        builder.append(ex.getContentType());
        builder.append(" media type is not supported. Supported media types are ");
        ex.getSupportedMediaTypes().forEach(t -> builder.append(t + " "));

        final APIResponseData apiError = new APIResponseData(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value(), builder.toString());
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

        logger.info(ex.getClass().getName());
        final String error = "Message could not readable.";
        APIResponseData apiError = new APIResponseData(HttpStatus.BAD_REQUEST.value(), error);
        return new ResponseEntity<>(apiError, HttpStatus.OK);
    }

    // 500
    @ExceptionHandler({Exception.class, InternalServiceException.class})
    public ResponseEntity<Object> handleAll(final Exception ex, final WebRequest request) {
        logger.info(ex.getClass().getName());
        logger.error("Error: GlobalExceptionHandler.handleAll ==> ", ex);

        return new ResponseEntity<Object>(processError(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), null),
                new HttpHeaders(), HttpStatus.OK);
    }

    // 503
    @ExceptionHandler({ServiceIntegrationException.class})
    public ResponseEntity<Object> handleServiceIntegrationException(final Exception ex, final WebRequest request) {
        logger.info(ex.getClass().getName());
        logger.error("Error: handleServiceIntegrationException.handleAll ==> ", ex);

        return new ResponseEntity<Object>(processError(HttpStatus.SERVICE_UNAVAILABLE.value(), HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase(), null),
                new HttpHeaders(), HttpStatus.OK);
    }

    // 509
    @ExceptionHandler({BandwidthException.class})
    public ResponseEntity<Object> handleBandWidthException(final Exception ex, final WebRequest request) {
        logger.info(ex.getClass().getName());
        logger.error("Error: handleServiceIntegrationException.handleBandWidthException ==> ", ex);

        return new ResponseEntity<Object>(processError(HttpStatus.BANDWIDTH_LIMIT_EXCEEDED.value(), HttpStatus.BANDWIDTH_LIMIT_EXCEEDED.getReasonPhrase(), null),
                new HttpHeaders(), HttpStatus.OK);
    }

    private APIResponseData processError(int aPResponseCode, String aPResponseMessage, List<ErrorResource> aPErrorResource) {
        StatusResource error = new StatusResource(aPResponseCode, aPResponseMessage);
        error.setErrors(aPErrorResource);
        return new APIResponseData(error, null);
    }

    private String mapMessageToErrMessage(Class enumClass, String defaultMessage) {
        if (StringUtils.isNotBlank(defaultMessage) && null != enumClass) {
            try {
                ErrMessage enumInstance;
                try {
                    enumInstance = (ErrMessage) ErrMessage.getInstance(defaultMessage.trim(), enumClass);
                } catch (IllegalArgumentException ex) {
                    enumInstance = ErrMessage.getInstance(defaultMessage.trim(), ErrMessageEnum.class);
                }
                return ((ErrMessage) enumInstance.lookup(defaultMessage.trim())).getMessage();
            } catch (Exception ex) {
                logger.warn("Error: handleInvalidDataException.mapMessageToErrMessage ==> ", ex);
                return defaultMessage;
            }
        } else {
            return defaultMessage;
        }
    }

    private String mapFieldToErrMessage(Class enumClass, String fieldCode, String defaultMessage) {
        if (StringUtils.isNotBlank(defaultMessage) && null != enumClass) {
            try {
                ErrMessage enumInstance;
                try {
                    enumInstance = (ErrMessage) ErrMessage.getInstance(defaultMessage.trim(), enumClass);
                } catch (IllegalArgumentException ex) {
                    enumInstance = ErrMessage.getInstance(defaultMessage.trim(), ErrMessageEnum.class);
                }
                return ((ErrMessage) enumInstance.lookup(defaultMessage.trim())).getFullyQualifiedFieldName();
            } catch (Exception ex) {
                logger.warn("Error: handleInvalidDataException.mapFieldToErrMessage ==> ", ex);
                return fieldCode;
            }
        } else {
            return fieldCode;
        }
    }
}