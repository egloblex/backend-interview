package com.altruist.exception;

public class InternalServiceException extends CommonException {
    public InternalServiceException(String message) {
        super(message);
    }
}