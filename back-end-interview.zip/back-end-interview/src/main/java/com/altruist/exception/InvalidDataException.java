package com.altruist.exception;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;

@SuppressWarnings("serial")
public class InvalidDataException extends RuntimeException {
    private final BindingResult errors;
    private Class enumClass;

    public InvalidDataException(BindingResult errors, String message) {
        super(message);
        this.errors = errors;
    }

    public InvalidDataException(BindingResult errors, String message, Class enumClass) {
        super(message);
        this.errors = errors;
        this.enumClass = enumClass;
    }

    public InvalidDataException(String message) {
        super(message);
        errors = null;
    }

    public InvalidDataException(String message, Class enumClass) {
        super(message);
        errors = null;
        this.enumClass = enumClass;
    }

    public InvalidDataException(BindingResult errors) {
        super();
        this.errors = errors;
    }

    public InvalidDataException(BindingResult errors, Class enumClass) {
        super();
        this.errors = errors;
        this.enumClass = enumClass;
    }

    Errors getErrors() {
        return errors;
    }

    public Class getEnumClass() {
        return enumClass;
    }

    public void setEnumClass(Class enumClass) {
        this.enumClass = enumClass;
    }
}