package com.altruist.exception;

public class OrderServiceException extends Exception {

  private static final long serialVersionUID = -8702678683643775070L;

  public OrderServiceException(String message) {
    super(message);
  }

  public OrderServiceException(String message, Throwable cause) {
    super(message, cause);
  }
}
