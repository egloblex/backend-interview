package com.altruist.exception;

public class UnAuthorizedException extends CommonException {
    public UnAuthorizedException(String message) {
        super(message);
    }
}