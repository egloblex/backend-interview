package com.altruist.exception;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;

@SuppressWarnings("serial")
public class InvalidRequestException extends RuntimeException {
    private final BindingResult errors;

    public InvalidRequestException(BindingResult errors, String message) {
        super(message);
        this.errors = errors;
    }

    public InvalidRequestException(String message) {
        super(message);
        errors = null;
    }

    public InvalidRequestException(BindingResult errors) {
        super();
        this.errors = errors;
    }

    Errors getErrors() {
        return errors;
    }
}