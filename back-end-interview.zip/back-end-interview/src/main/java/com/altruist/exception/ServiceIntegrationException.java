package com.altruist.exception;

public class ServiceIntegrationException extends CommonException {
    public ServiceIntegrationException(String message) {
        super(message);
    }
}