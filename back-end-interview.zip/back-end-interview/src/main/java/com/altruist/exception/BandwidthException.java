package com.altruist.exception;

public class BandwidthException extends CommonException {
    public BandwidthException(String message) {
        super(message);
    }
}