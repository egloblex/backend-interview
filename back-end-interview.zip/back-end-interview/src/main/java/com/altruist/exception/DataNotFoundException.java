package com.altruist.exception;

public class DataNotFoundException extends CommonException {
    public DataNotFoundException(String message) {
        super(message);
    }
}