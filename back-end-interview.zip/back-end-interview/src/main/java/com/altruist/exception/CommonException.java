package com.altruist.exception;

public abstract class CommonException extends RuntimeException {

    private final String message;

    CommonException(String message) {
        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}