package com.altruist.order.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class CancelOrderRequest {
    public UUID orderId;
    public String serverId;
    public String machineId;
    public long eventId;
}
