package com.altruist.order.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class CancelOrderResponse {
    public UUID orderId;
    public boolean isSuccessful;
    public String reason;
}
