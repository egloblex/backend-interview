package com.altruist.order.rest;

import com.altruist.common.APIResponseData;
import com.altruist.order.dto.CancelOrderDto;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.ValidateAndConvertCancelOrder;
import com.altruist.order.services.CancelOrderSrv;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("/cancel")
@Slf4j
public class CancelOrderCtrl {

    private final CancelOrderSrv cancelOrderSrc;

    public CancelOrderCtrl(CancelOrderSrv cancelOrderSrc) {
        this.cancelOrderSrc = cancelOrderSrc;
    }

    @PostMapping(consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<APIResponseData<CancelOrderResponse>> cancelOrder(
            @RequestBody @Valid CancelOrderDto cancelOrderDto,
            HttpServletRequest httpServletRequest
    ) throws InterruptedException {
        log.info("Received cancel order request [{}].", cancelOrderDto);

        CancelOrderResponse newOrderResponse = cancelOrderSrc.sendCancelOrder(ValidateAndConvertCancelOrder.convertDtoToModel(cancelOrderDto));
        return new ResponseEntity(new APIResponseData<>(HttpStatus.OK, newOrderResponse), HttpStatus.OK);
    }
}
