package com.altruist.order.dto;

import java.util.Objects;
import java.util.UUID;

public class OrderEntryToCancelOrderRequest {
    public static CancelOrderRequest convertOEToCOR(OrderEntry oe) {
        CancelOrderRequest cancelOrder = new CancelOrderRequest();
        cancelOrder.eventId = Objects.requireNonNull(oe.getEventId(), "EventId can't be null");
        cancelOrder.machineId = Objects.requireNonNull(oe.getMachineId(), "MachineId can't be null");
        cancelOrder.orderId = Objects.requireNonNull(oe.getOrderId(), "OrderId can't be null");
        cancelOrder.serverId = Objects.requireNonNull(oe.getServerId(), "ServerId can't be null");
        return cancelOrder;
    }
}
