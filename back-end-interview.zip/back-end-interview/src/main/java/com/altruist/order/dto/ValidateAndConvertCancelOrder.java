package com.altruist.order.dto;

import java.util.Objects;
import java.util.UUID;

public class ValidateAndConvertCancelOrder {
    public static CancelOrderRequest convertDtoToModel(CancelOrderDto cancelOrderDto) {
        CancelOrderRequest cancelOrder = new CancelOrderRequest();
        cancelOrder.eventId = Long.valueOf(Objects.requireNonNull(cancelOrderDto.getEventId(), "EventId can't be null"));
        cancelOrder.machineId = Objects.requireNonNull(cancelOrderDto.getMachineId(), "MachineId can't be null");
        cancelOrder.orderId = UUID.fromString(Objects.requireNonNull(cancelOrderDto.getOrderId(), "OrderId can't be null"));
        cancelOrder.serverId = Objects.requireNonNull(cancelOrderDto.getServerId(), "ServerId can't be null");
        return cancelOrder;
    }
}
