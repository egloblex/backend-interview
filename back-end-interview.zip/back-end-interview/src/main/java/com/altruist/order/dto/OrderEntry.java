package com.altruist.order.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
public class OrderEntry {
    public UUID orderId;
    public int status;
    public String symbol;
    public UUID account;
    public int quantity;
    public int side;
    public double price;
    public LocalDate sessionDate;
    public String serverId;
    public String machineId;
    public long eventId;
    public long msgSeq;
    public LocalDateTime engRecTime;
}
