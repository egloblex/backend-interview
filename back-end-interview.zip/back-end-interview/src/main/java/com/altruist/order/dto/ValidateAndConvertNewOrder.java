package com.altruist.order.dto;

import java.time.LocalDate;
import java.util.Objects;
import java.util.UUID;

public class ValidateAndConvertNewOrder {
    public static OrderEntry convertDtoToModel(NewOrderDto newOrderDto) {
        OrderEntry orderEntry = new OrderEntry();
        orderEntry.account = UUID.fromString(Objects.requireNonNull(newOrderDto.getAccount(), "Account can't be null"));
        orderEntry.symbol = Objects.requireNonNull(newOrderDto.getSymbol(), "Symbol can't be null");
        orderEntry.quantity = Objects.requireNonNull(newOrderDto.getQuantity(), "Quantity can't be null");
        orderEntry.side = Objects.requireNonNull(newOrderDto.getSide(), "Side can't be null");
        orderEntry.price = Objects.requireNonNull(newOrderDto.getPrice(), "Price can't be null");
        orderEntry.sessionDate = LocalDate.now();
        return orderEntry;
    }
}
