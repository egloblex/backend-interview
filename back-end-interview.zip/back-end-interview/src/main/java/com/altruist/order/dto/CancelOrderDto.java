package com.altruist.order.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CancelOrderDto {
    //From client point of view, we only need orderId to cancel the order.
    //Here I try to avoid to repopulate other info, just ask the client to send them back.
    //We should not rely on this, but it does improve the engine performance.
    public String orderId;
    public String serverId;
    public String machineId;
    public String eventId;
}
