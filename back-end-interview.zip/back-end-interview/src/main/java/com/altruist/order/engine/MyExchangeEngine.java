package com.altruist.order.engine;

import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.OrderEntry;
import com.altruist.order.messaging.AdminOperation;
import com.altruist.order.messaging.OrderBus;
import com.altruist.order.repo.OrdersRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
@Order(0)
@Slf4j
class MyExchangeEngine implements ApplicationListener<ApplicationReadyEvent> {
    private final OrderBus orderBus;
    private final EngineOrdersSrv engineOrdersSrv;
    private final EngineCancelOrderSrv engineCancelOrderSrv;
    private ExecutorService executorService;
    private boolean started;

    public MyExchangeEngine(OrderBus orderBus, EngineOrdersSrv engineOrdersSrv, EngineCancelOrderSrv engineCancelOrderSrv) {
        this.orderBus = orderBus;
        this.engineOrdersSrv = engineOrdersSrv;
        this.engineCancelOrderSrv = engineCancelOrderSrv;
        this.executorService = Executors.newSingleThreadExecutor();
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        log.info("Start my exchange engine");
        this.started = true;
        executorService.submit(()->startServer());
    }

    private void startServer() {
        while (started) {
            AdminOperation adminOp = orderBus.getAdminOperationAckChannel().poll();
            if (adminOp != null) {
                if (adminOp.getCode() == AdminOperation.Code.ORDER_ENTRY) {
                    OrderEntry oe = engineOrdersSrv.saveNewOrder(adminOp.getData(OrderEntry.class));
                    orderBus.getAdminOperationAckChannel().offer(new AdminOperation(AdminOperation.Code.ORDER_ENTRY, oe, AdminOperation.Type.PRIMARY_RESPONSE));
                } else if (adminOp.getCode() == AdminOperation.Code.CANCEL_ORDER_REQUEST) {
                    //We should send a notification event to order book to get the order entry to be removed and persist the db from there.
                    //Here just for simplifying the demo purpose
                    CancelOrderResponse response = engineCancelOrderSrv.cancelOrder(adminOp.getData(CancelOrderRequest.class));
                    orderBus.getCancelOrderAckChannel().offer(response);
                }
            }
        }
    }
}