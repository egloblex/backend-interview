package com.altruist.order.messaging;

import com.altruist.exception.ServiceIntegrationException;
import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.OrderEntry;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.LinkedBlockingQueue;

/*
 * OrderBus simulates a message queue system, it is not thread safe and it is also not checking if the ack is the right
 * ack of the message sent. We assume the server send the ack sequentially.
 */

@Data
@NoArgsConstructor
@Component
public class OrderBus {
    public LinkedBlockingQueue<OrderEntry> orderEntryChannel = new LinkedBlockingQueue<>();
    public LinkedBlockingQueue<OrderEntry> orderEntryAckChannel = new LinkedBlockingQueue();

    public LinkedBlockingQueue<AdminOperation> adminOperationChannel = new LinkedBlockingQueue();

    public LinkedBlockingQueue<CancelOrderRequest> cancelOrderChannel = new LinkedBlockingQueue<>();
    public LinkedBlockingQueue<CancelOrderResponse> cancelOrderAckChannel = new LinkedBlockingQueue();

    public LinkedBlockingQueue<AdminOperation> adminOperationAckChannel = new LinkedBlockingQueue();

    public CancelOrderResponse sendToCancelOrderTopicAndGetAck(CancelOrderRequest cancelOrderRequest) throws ServiceIntegrationException, InterruptedException {
        cancelOrderChannel.put(cancelOrderRequest);
        return cancelOrderAckChannel.take();
    }

    public OrderEntry sendToNewOrderTopicAndGetAck(OrderEntry orderEntry) throws ServiceIntegrationException, InterruptedException{
        orderEntryChannel.put(orderEntry);
        return orderEntryAckChannel.take();
    }
}
