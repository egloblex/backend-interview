package com.altruist.order.engine;

import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.OrderEntry;
import com.altruist.order.repo.OrdersRepo;
import org.springframework.stereotype.Component;

@Component
public class EngineCancelOrderSrv {
    private final OrdersRepo ordersRepo;

    public EngineCancelOrderSrv(OrdersRepo ordersRepo) {
        this.ordersRepo = ordersRepo;
    }

    public CancelOrderResponse cancelOrder(CancelOrderRequest cancelOrderRequest) {
        //Fire an event to order book to remove the entry in order book. Theory point of view we should get ack from order book to safely cancel order and persist the data.
        return ordersRepo.cancelOrder(cancelOrderRequest);
    }

    //This method doesn't sanity check orderEntry so be careful, where orderEntry.status is 2 and with different event_id or msg_seq
    public OrderEntry cancelOrderHistory(OrderEntry orderEntry) {
        return ordersRepo.saveOrderHistory(orderEntry);
    }
}
