package com.altruist.order.repo;

import com.altruist.exception.InternalServiceException;
import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.OrderEntry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Repository
@Slf4j
public class OrdersRepo {
    private static final OrderEntryMapper ORDER_ENTRY_MAPPER = new OrderEntryMapper();
    private final NamedParameterJdbcOperations jdbcOperations;

    public OrdersRepo(NamedParameterJdbcOperations jdbcOperations) {
        this.jdbcOperations = jdbcOperations;
    }

    public OrderEntry saveOrders(OrderEntry orderEntry) {
        BeanPropertySqlParameterSource params = new BeanPropertySqlParameterSource(orderEntry);
        KeyHolder keyHolder = new GeneratedKeyHolder();
        log.info("Saving account [{}].", orderEntry);
        String sql = "INSERT INTO trade.orders (event_id,order_status,machine_id) VALUES (:eventId, :status, :machineId)";
        jdbcOperations.update(sql, params, keyHolder);
        UUID id;
        Map<String, Object> keys = keyHolder.getKeys();
        if (null != keys) {
            id = (UUID) keys.get("order_id");
            log.info("Inserted orders record {}.", id);
            orderEntry.orderId = id;
        } else {
            log.warn("Insert of orders record failed. {}", orderEntry);
            throw new InternalServiceException("Insert failed for account");
        }
        return orderEntry;
    }

    public OrderEntry saveOrderHistory(OrderEntry orderEntry) {
        BeanPropertySqlParameterSource params = new BeanPropertySqlParameterSource(orderEntry);
        log.info("Saving account [{}].", orderEntry);
        String sql = "INSERT INTO trade.order_history (order_id,event_id,machine_id,server_id,account,symbol,order_side,order_status, order_price, order_qty, msg_seq, session_date) " +
                "VALUES (:orderId, :eventId, :machineId, :serverId, :account, :symbol, :side, :status, :price, :quantity, :msgSeq, :sessionDate)";
        jdbcOperations.update(sql, params);
        return orderEntry;
    }

    public List<OrderEntry> retrieveOrderEntry(UUID account) {
        String sql = "select o.* from trade.order_history o where o.account = " + account;
        return jdbcOperations.query(sql, ORDER_ENTRY_MAPPER);
    }

    public CancelOrderResponse cancelOrder(CancelOrderRequest cancelOrderRequest) {
        //status: 1 - submitted, 2 - canceled, 3 - completed, 100 - failed, should use enum, but embedded here for simplicity
        String sql = "Update trade.orders set order_status = 2 where order_status = 1 and order_id = :orderId and event_id = :eventId and machine_id = :machineId";
        SqlParameterSource parameters = new MapSqlParameterSource().addValue("orderId", cancelOrderRequest.getOrderId())
                .addValue("eventId", cancelOrderRequest.getEventId())
                .addValue("machineId", cancelOrderRequest.getMachineId());
        int updated = jdbcOperations.update(sql, parameters);
        CancelOrderResponse response = new CancelOrderResponse();
        response.orderId = cancelOrderRequest.getOrderId();
        response.isSuccessful = updated == 1;
        response.reason = updated != 1 ? "It has been already executed." : "";
        return response;
    }
}
