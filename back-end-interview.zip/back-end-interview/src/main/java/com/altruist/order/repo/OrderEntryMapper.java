package com.altruist.order.repo;

import com.altruist.order.dto.OrderEntry;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class OrderEntryMapper implements RowMapper<OrderEntry>  {
    @Override
    public OrderEntry mapRow(ResultSet rs, int rowNum) throws SQLException {
        OrderEntry oe = new OrderEntry();
        oe.msgSeq = rs.getLong("msg_seq");
        oe.account = rs.getObject("account", UUID.class);
        oe.eventId = rs.getLong("event_id");
        oe.machineId = rs.getString("machine_id");
        oe.serverId = rs.getString("server_id");
        oe.orderId = rs.getObject("order_id", UUID.class);
        oe.price = rs.getDouble("order_price");
        oe.quantity = rs.getInt("order_qty");
        oe.side = rs.getInt("side");
        oe.sessionDate = rs.getTimestamp("session_date").toLocalDateTime().toLocalDate();
        oe.engRecTime = rs.getTimestamp("eng_received_time").toLocalDateTime();
        return null;
    }
}
