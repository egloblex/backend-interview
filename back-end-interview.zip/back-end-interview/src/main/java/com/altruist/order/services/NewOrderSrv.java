package com.altruist.order.services;

import com.altruist.order.dto.OrderEntry;
import com.altruist.order.messaging.OrderBus;
import org.springframework.stereotype.Component;

@Component
public class NewOrderSrv {
    private final OrderBus orderBus;
    public NewOrderSrv(OrderBus orderBus) {
        this.orderBus = orderBus;
    }

    public OrderEntry sendNewOrder(OrderEntry orderEntry) throws InterruptedException {
        return orderBus.sendToNewOrderTopicAndGetAck(orderEntry);
    }
}
