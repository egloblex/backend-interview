package com.altruist.order.rest;

import com.altruist.common.APIResponseData;
import com.altruist.order.dto.OrderEntry;
import com.altruist.order.services.OrderRetrieveSrv;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("/orders/")
@Slf4j
public class OrderRetrieveCtrl {

    private final OrderRetrieveSrv orderRetrieveSrv;

    public OrderRetrieveCtrl(OrderRetrieveSrv orderRetrieveSrv) {
        this.orderRetrieveSrv = orderRetrieveSrv;
    }

    @PostMapping(value = "/{account}", produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<APIResponseData<List<OrderEntry>>> retrieveOrderEntries(@PathVariable String account) {
        log.info("Received order entry retrieve request [{}].", account);
        List<OrderEntry> oes = orderRetrieveSrv.retrieveOrderEntries(account);
        return new ResponseEntity(new APIResponseData<>(HttpStatus.OK, oes), HttpStatus.OK);
    }
}
