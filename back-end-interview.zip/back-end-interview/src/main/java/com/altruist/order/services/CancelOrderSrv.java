package com.altruist.order.services;

import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.messaging.OrderBus;
import org.springframework.stereotype.Component;

@Component
public class CancelOrderSrv {
    private final OrderBus orderBus;
    public CancelOrderSrv(OrderBus orderBus) {
        this.orderBus = orderBus;
    }

    public CancelOrderResponse sendCancelOrder(CancelOrderRequest cancelOrderRequest) throws InterruptedException {
        return orderBus.sendToCancelOrderTopicAndGetAck(cancelOrderRequest);
    }
}
