package com.altruist.order.messaging;

import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.OrderEntry;

public class AdminOperation {
    public enum Code {
        ORDER_ENTRY(OrderEntry.class),
        CANCEL_ORDER_REQUEST(CancelOrderRequest.class),
        CANCEL_ORDER_RESPONSE(CancelOrderResponse.class);

        private final Class<?> clazz;

        private Code() {
            this.clazz = null;
        }

        private Code(final Class<?> clazz) {
            this.clazz = clazz;
        }

        private Class<?> getClassName() {
            return clazz;
        }
    }

    public enum Type {
        TO_MATCH,
        FROM_MATCH,
        PRIMARY_RESPONSE,
        INTERNAL_REQUEST,
        INTERNAL_RESPONSE
    }

    // what type of AdminOperation this is
    private final Code code;

    // arbitrary data, can be null
    private final Object data;

    private Type messageType = null;

    public AdminOperation(final Code operationCode, final Type type) {
        this(operationCode, /* (Object) */null, type);
    }

    public AdminOperation(final Code code, final Object data, final Type type) {
        if (code == null) {
            throw new IllegalArgumentException("null Code not allowed");
        }
        if (data == null) {
            this.code = code;
            this.data = null;
            this.messageType = type;
        }
        else {
            if (code.getClassName() == null) {
                throw new IllegalArgumentException("Attempted to assign non-null Data for a Code with a null type");
            }
            else {
                if (isAssignable(code, data)) {
                    this.code = code;
                    this.data = data;
                    this.messageType = type;
                }
                else {
                    throw new IllegalArgumentException("Class of Object data (" + data.getClass().getName()
                            + ") does not match Class linked to Code (" + code.getClassName().getName() + ")");
                }
            }
        }
    }

    public Code getCode() {
        return code;
    }

    public Object getData() {
        return data;
    }

    private boolean isAssignable(final Code code, final Object data){
        try{
            final Class<?> class1 = Class.forName(code.getClassName().getName());
            final Class<?> class2 = Class.forName(data.getClass().getName());
            return class1.isAssignableFrom(class2);
        } catch (final ClassNotFoundException ex) {
            throw new IllegalArgumentException("Unknown class when comparing " + code.getClassName().getName() +
                    " and " + data.getClass().getName() + ". Exception: " + ex);
        }
    }

    public <T> T getData(final Class<T> clazz) {
        if (data == null) {
            return null;
        }
        if (clazz.isInstance(data)) {
            // unchecked they say, but wrapped in instanceof so should be ok!
            @SuppressWarnings("unchecked")
            final
            T retval = (T) data;
            return retval;
        }
        else {
            throw new IllegalArgumentException("Attempted to retrieve data of an incompatible class.  Desired class: "
                    + clazz.getName() + ", found class: " + data.getClass().getName());
        }
    }
}
