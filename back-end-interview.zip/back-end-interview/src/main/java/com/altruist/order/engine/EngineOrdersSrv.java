package com.altruist.order.engine;

import com.altruist.order.dto.OrderEntry;
import com.altruist.order.repo.OrdersRepo;
import org.springframework.stereotype.Component;

@Component
public class EngineOrdersSrv {
    private final OrdersRepo ordersRepo;

    public EngineOrdersSrv(OrdersRepo ordersRepo) {
        this.ordersRepo = ordersRepo;
    }

    //It seems that we should lock or put transaction, but we will save multiple rows of records given event_id and msg_seq changing
    //In other word, we don't want to lock but by using space for speed.
    public OrderEntry saveNewOrder(OrderEntry orderEntry) {
        orderEntry.status = 1;
        return ordersRepo.saveOrderHistory(ordersRepo.saveOrders(orderEntry));
    }

    //This method doesn't sanity check orderEntry so be careful.
    public OrderEntry saveOrderHistory(OrderEntry orderEntry) {
        return ordersRepo.saveOrderHistory(orderEntry);
    }
}
