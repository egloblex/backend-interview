package com.altruist.order.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class NewOrderDto {
    public String symbol;
    public String account;
    public Integer quantity;
    public Integer side;
    public Double price;
}
