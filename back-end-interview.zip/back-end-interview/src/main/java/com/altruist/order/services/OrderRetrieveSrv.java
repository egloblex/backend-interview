package com.altruist.order.services;

import com.altruist.order.dto.OrderEntry;
import com.altruist.order.repo.OrdersRepo;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class OrderRetrieveSrv {
    private final OrdersRepo ordersRepo;

    public OrderRetrieveSrv(OrdersRepo ordersRepo) {
        this.ordersRepo = ordersRepo;
    }
    public List<OrderEntry> retrieveOrderEntries(String account) {
        return ordersRepo.retrieveOrderEntry(UUID.fromString(account));
    }
}
