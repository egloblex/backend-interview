package com.altruist.order.rest;

import com.altruist.common.APIResponseData;
import com.altruist.exception.InvalidDataException;
import com.altruist.order.dto.NewOrderDto;
import com.altruist.order.dto.OrderEntry;
import com.altruist.order.dto.ValidateAndConvertNewOrder;
import com.altruist.order.services.NewOrderSrv;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("/orders")
@Slf4j
public class NewOrderCtrl {

    private final NewOrderSrv newOrderSrv;

    public NewOrderCtrl(NewOrderSrv newOrderSrv) {
        this.newOrderSrv = newOrderSrv;
    }

    @PostMapping(consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<APIResponseData<OrderEntry>> create(
            @RequestBody @Valid NewOrderDto newOrderDto,
            HttpServletRequest httpServletRequest
    ) throws URISyntaxException, InterruptedException {
        log.info("Received new order request [{}].", newOrderDto);
        if (newOrderDto.getPrice() <=0 || newOrderDto.getQuantity() <= 0) { //For simplicity we check them together
            throw new InvalidDataException("Price or Quantity must be greater than 0");
        }
        OrderEntry newOrderResponse = newOrderSrv.sendNewOrder(ValidateAndConvertNewOrder.convertDtoToModel(newOrderDto));
        return ResponseEntity.created(new URI(httpServletRequest.getRequestURL() + "/" + newOrderDto.account))
                .body(new APIResponseData<>(HttpStatus.CREATED, newOrderResponse));
    }
}
