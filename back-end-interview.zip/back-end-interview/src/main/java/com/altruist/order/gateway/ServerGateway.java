package com.altruist.order.gateway;

import com.altruist.order.dto.CancelOrderRequest;
import com.altruist.order.dto.CancelOrderResponse;
import com.altruist.order.dto.OrderEntry;
import com.altruist.order.messaging.AdminOperation;
import com.altruist.order.messaging.OrderBus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * server gateway route order entries in and out. In future state, there should also route market date entries.
 *
 */
@Component
@Order(0)
@Slf4j
public class ServerGateway implements ApplicationListener<ApplicationReadyEvent>  {
    private final OrderBus orderBus;
    private ExecutorService executorService;
    private boolean started;
    private AtomicInteger eventId;
    private AtomicInteger msgSeq;

    public ServerGateway(OrderBus orderBus) {
        this.orderBus = orderBus;
        executorService = Executors.newSingleThreadExecutor();
        eventId = new AtomicInteger(10000);
        msgSeq = new AtomicInteger(50000);
    }


    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        start_gateway();
    }

    private void start_gateway() {
        this.started = true;
        executorService.submit(()->start());
    }

    private void start() {
        while (started) {
            OrderEntry orderEntry = null;
            do {
                orderEntry = orderBus.getOrderEntryChannel().poll();
                if (orderEntry != null) {
                    //route the order to right channel, default we have only one channel
                    orderEntry.serverId = "localhost";
                    orderEntry.machineId = "127.0.0.1";
                    orderEntry.eventId = eventId.getAndIncrement(); // should be generated in event source
                    orderEntry.msgSeq = msgSeq.getAndIncrement(); //should be generated in message source
                    orderBus.getAdminOperationChannel().offer(new AdminOperation(AdminOperation.Code.ORDER_ENTRY, orderEntry,
                            AdminOperation.Type.INTERNAL_REQUEST));

                }
            } while (orderEntry != null);

            CancelOrderRequest cancelOrder = null;
            do {
                cancelOrder = orderBus.getCancelOrderChannel().poll();
                if (cancelOrder != null) {
                    orderBus.getAdminOperationChannel().offer(new AdminOperation(AdminOperation.Code.CANCEL_ORDER_REQUEST,
                            cancelOrder, AdminOperation.Type.INTERNAL_REQUEST));
                }
            } while (cancelOrder != null);

            AdminOperation adminOp = null;
            do {
                adminOp = orderBus.getAdminOperationAckChannel().poll();
                if (adminOp != null) {
                    if (adminOp.getCode() == AdminOperation.Code.ORDER_ENTRY) {
                        OrderEntry newOrderResponse = adminOp.getData(OrderEntry.class);
                        orderBus.getOrderEntryAckChannel().offer(newOrderResponse);
                    } else if (adminOp.getCode() == AdminOperation.Code.CANCEL_ORDER_RESPONSE) {
                        CancelOrderResponse cancelOrderResponse = adminOp.getData(CancelOrderResponse.class);
                        orderBus.getCancelOrderAckChannel().offer(cancelOrderResponse);
                    }
                }
            } while (adminOp != null);
        }
    }
}
