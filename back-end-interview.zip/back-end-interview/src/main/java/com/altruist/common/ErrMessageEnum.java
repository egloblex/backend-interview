/*
 * ===========================================================================
 * <p/>
 * Copyright (c) 2017 Allstate Insurance Company
 * All rights reserved.
 * <p/>
 * This program may not be duplicated, disclosed or provided to any third parties
 * without the prior written consent of Life Technology Solution.
 * Disassembly or decompilation of the software and/or reverse engineering
 * of the object code are prohibited.
 * <p/>
 * =============================================================================
 * Purpose
 * Remarks
 * <p/>
 * Revision History:
 * When        Who           What
 * -----------------------------------------------------------------------------
 * Aug 30, 2017    ssooe        Base version
 */

package com.altruist.common;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ErrMessageEnum implements ErrMessage<ErrMessageEnum> {
    // RegEx, min Length, Max length, message, fully qualified field name, field name

    // Header Error Messages
    INVALID_X_USER_INFO("", -1, -1, "Invalid User Info. (X-User-Info).", "userInfo", "userInfo"),
    INVALID_ATTRIBUTES("", -1, -1, "Invalid Field Name.", "resource.attributes[{0}].filedName", "filedName"),
    INVALID_FIELDS("", -1, -1, "Invalid Field Name.", "resource.attributes[{0}].filedNames[{0}]", "filedName");

    private final String regexValue;
    private final int minLength;
    private final int maxLength;
    private final String message;
    private final String fullyQualifiedFieldName;
    private final String fieldName;
}
