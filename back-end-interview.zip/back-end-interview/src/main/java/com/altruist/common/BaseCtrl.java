package com.altruist.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ModelAttribute;

import javax.servlet.http.HttpServletRequest;

@Slf4j
public class BaseCtrl<E extends APIHeader> {

    @ModelAttribute("header")
    public E populate(E aPHeaders, HttpServletRequest aPRequest) {

        if (aPHeaders != null && aPRequest != null) {
            // set all kind of header
        }
        return aPHeaders;
    }
}
