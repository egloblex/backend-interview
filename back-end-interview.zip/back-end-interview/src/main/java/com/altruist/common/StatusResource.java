package com.altruist.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class StatusResource {
    private int code;
    private String description;

    private List<ErrorResource> errors;

    public StatusResource(int code, String description) {
        this.code = code;
        this.description = description;
    }
}