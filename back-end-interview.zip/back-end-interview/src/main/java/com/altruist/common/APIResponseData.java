package com.altruist.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class APIResponseData<T> {
    T data;
    StatusResource status;

    public APIResponseData(int statusCd, String message) {
        this.status = new StatusResource(statusCd, message);
    }

    public APIResponseData(StatusResource status, T data) {
        this.status = status;
        this.data = data;
    }

    public APIResponseData(HttpStatus lvHttpStatus, T data) {
        StatusResource lvStatus = new StatusResource(lvHttpStatus.value(), lvHttpStatus.getReasonPhrase());
        this.status = lvStatus;
        this.data = data;
    }

    public APIResponseData(T data) {
        StatusResource lvStatus = new StatusResource(HttpStatus.OK.value(), HttpStatus.OK.getReasonPhrase());
        this.status = lvStatus;
        this.data = data;
    }
}
