package com.altruist.common;

public interface ErrMessage<E extends Enum<E>> {

    public static <E extends Enum<E>> E getInstance(final String value, final Class<E> enumClass) {
        return Enum.valueOf(enumClass, value);
    }

    String getRegexValue();

    int getMinLength();

    int getMaxLength();

    String getMessage();

    String getFullyQualifiedFieldName();

    String getFieldName();

    Class<E> getDeclaringClass();

    default E lookup(String name) {
        try {
            return Enum.valueOf(getDeclaringClass(), name);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
