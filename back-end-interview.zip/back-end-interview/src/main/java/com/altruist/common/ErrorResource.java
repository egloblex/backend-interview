package com.altruist.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ErrorResource {
    private String field;
    private String message;

    @JsonIgnore
    private String code;
    @JsonIgnore
    private String resource;
}