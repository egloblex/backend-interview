/*
 * ===========================================================================
 * <p/>
 * Copyright (c) 2017 Allstate Insurance Company
 * All rights reserved.
 * <p/>
 * This program may not be duplicated, disclosed or provided to any third parties
 * without the prior written consent of Life Technology Solution.
 * Disassembly or decompilation of the software and/or reverse engineering
 * of the object code are prohibited.
 * <p/>
 * =============================================================================
 * Purpose
 * Remarks
 * <p/>
 * Revision History:
 * When        Who           What
 * -----------------------------------------------------------------------------
 * Mar 24, 2017    sbabv        Base version
 */
package com.altruist.common;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

@Data
@Slf4j
public class APIHeader {
    public static final String HEADER_AUTHORIZATION = "X-Authorization";
    public static final String HEADER_CHANNEL_ID = "X-Channel-Id";
    public static final String HEADER_REQUEST_ID = "X-Request-Id";
    public static final String HEADER_SYS_INFO = "X-System-Info";
    public static final String HEADER_OS_INFO = "X-OS-Info";
    public static final String HEADER_BROWSER_INFO = "X-Browser-Info";
    public static final String HEADER_USER_INFO = "X-User-Info";
    public static final String HEADER_ORIGIN_CHANNEL_INFO = "X-Origin-Channel-Id";
    public static final String HEADER_PLATFORM_CORRELATION_ID = "X-PlatformCorrelation-Id";
    public static final String HEADER_RESTRICTED_DATA = "X-Restricted-Data";
    public static final String HEADER_ACCEPT = "Accept";

    // Some other attributes or tokens

    private Map<String, String> trimKeyValue(Map<String, String> aPMap) {
        Map<String, String> trimmedMap = new HashMap<>();
        for (Map.Entry<String, String> entry : aPMap.entrySet()) {
            if (StringUtils.isNotBlank(entry.getKey())) {
                trimmedMap.put(entry.getKey().trim(), (null == entry.getValue()) ? "" : entry.getValue().trim());
            }
        }
        return trimmedMap;
    }
}