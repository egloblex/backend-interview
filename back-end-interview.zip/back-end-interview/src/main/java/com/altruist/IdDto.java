package com.altruist;

import lombok.AllArgsConstructor;

import java.util.UUID;

@AllArgsConstructor
public class IdDto {
  public UUID id;
}
